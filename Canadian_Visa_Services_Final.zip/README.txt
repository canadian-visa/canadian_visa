Canadian Visa Services — Static Website

Files:
- index.html — complete website
- canada-theme.png — Canadian-themed visual

Included:
- Canadian Visa Services title
- Canadian-themed background
- Automatic 3-stage visual slideshow
- Contact button linked to managementteamservice31@gmail.com
- Facebook button linked to https://www.fb.com/l/6lp1kJRRR
- Responsive mobile layout
- No backend required

To publish:
Upload both index.html and canada-theme.png to a static host such as GitHub Pages, Netlify, Cloudflare Pages, or Vercel.

Important:
The site is independent and does not represent the official Government of Canada website.
